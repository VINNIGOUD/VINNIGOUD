Class Demo
{
    public static void main(string[]args)
    {
        int i=1;
        d0
        {
            system.out.println(Ravi);
            system.out.println(vinay);
            i++;
             }
        while(i<=5)
     }
}